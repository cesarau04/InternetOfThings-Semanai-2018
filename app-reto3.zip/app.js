var config = {
    apiKey: "AIzaSyBI-ISFTpKEKiySTqAC1Gr4xiDJpLqqzO0",
    authDomain: "nodemcu-4974a.firebaseapp.com",
    databaseURL: "https://nodemcu-4974a.firebaseio.com",
    projectId: "nodemcu-4974a",
    storageBucket: "nodemcu-4974a.appspot.com",
    messagingSenderId: "16397337337"
  };
firebase.initializeApp(config);

//Variables de la vista de iniciar sesión
var user = document.getElementById("inputEmail");
var pass = document.getElementById("inputPassword");
var login = document.getElementById("logIn");
var error_login = document.getElementById("errorLogin");

//Variables del panel de control
var greetings = document.getElementById("welcomeText");
var humedad = document.getElementById("humedadValue");
var temperatura = document.getElementById("temperaturaValue");
var distancia = document.getElementById("distanciaValue");
var movimiento = document.getElementById("movimientoValue");
var movimiento_card = document.getElementById("movimientoCard");
var logout = document.getElementById("logOut");

const auth = firebase.auth();

login.addEventListener("click", function () {
  var email = user.value;
	var password= pass.value;

  console.log(email);
  console.log(password);
	auth.signInWithEmailAndPassword(email, password).catch(function(error) {
    $("#okayLogin").addClass("collapse");
	  $("#errorLogin").removeClass("collapse");
    console.log(error);
	});
});

auth.onAuthStateChanged(function(user) {
  if (user){
    $("#welcomeText").append("<p id='welcome'>Bienvenido " +user.email+ "</p>");
    $("#errorLogin").addClass("collapse");
    $("#okayLogin").removeClass("collapse");
    $("#loginPanel").addClass("collapse");
    $("#controlPanel").removeClass("collapse");

    var ref = firebase.database().ref();
    ref.on("value",function(data){
      $("#rm1").remove();
      $("#rm2").remove();
      $("#rm3").remove();
      $("#rm4").remove();
      var valores = Object.values(data.val());
      $("#humedadValue").append("<p id='rm1'>La humedad actual es " + valores[1] + "</p>");
      $("#temperaturaValue").append("<p id='rm2'>La temperatura actual es " + valores[5] + "</p>");
      $("#distanciaValue").append("<p id='rm3'>La distacia actual es " + valores[0] + "</p>");
      console.log(valores);
      if(valores[3]==0){
        $("#movimientoValue").append("<p id='rm4'>¡Todo bien!</p>");
        $("#movimientoCard").css("background-color","rgb(166, 244, 97)")
      }else{
        $("#movimientoValue").append("<p id='rm4'>¡CUIDADO!</p>");
        $("#movimientoCard").css("background-color","rgb(227, 118, 89)")
      }
    });
}else{
  $("#welcome").remove();
  $("#loginPanel").removeClass("collapse");
  $("#controlPanel").addClass("collapse");
  $("#okayLogin").delay(1000).fadeOut('slow');
}});


logout.addEventListener("click",function(){
	auth.signOut();
});
